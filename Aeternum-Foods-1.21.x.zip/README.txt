Aeternum Foods resource pack
================================

Este pack necesita AeternumSeasons 4.4 o posterior con SeasonFoods.
Incluye modelos CMD 2301-2313 y las apariencias de crecimiento.
No reemplaza trigo, remolacha ni alga vanilla.
Los cultivos Java se muestran con ItemDisplay centrado; el bloque real conserva
su mecanica. No se reemplaza ningun blockstate de manglar, hilo o cultivo vanilla.
