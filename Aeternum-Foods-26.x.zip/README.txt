Aeternum Foods resource pack
================================

Este pack necesita AeternumSeasons 4.4 o posterior con SeasonFoods.
Incluye modelos CMD 2301-2313 y las apariencias de crecimiento.
No reemplaza trigo, remolacha ni alga vanilla.
Los cultivos personalizados se muestran mediante cambios de bloque visuales
de mangrove_propagule enviados por el plugin; el bloque real conserva su mecánica.
